#include<stdio.h>
#include<conio.h>
#include<string.h>
#include<stdlib.h>
#include<math.h>
void clrscr(){system("cls || clear");}

/*-------------CH : THE DECISION CONTROL STRUCTURE ---------------- */

/* SOLUTION A :
                a.  Garbage 200
                b.  300 200
                c.  10  20
                d.  3
                e.  x and y are equal
                f.  x=10    y=10    z=0
                g.  0   50  0
                h.  C is WOW
                i.  a=15    b=15    c=0
                j.  1   20  1
*/

/* SOLUTION B :
                a.  for comparison == is used not =
                b.  No error
                c.  No error
                d.  'then' is not any keyword. therefore syntax error
                e.  Parenthesis is used for if condition in C
                f.  For comparison == is used not =
                g.  'elseif' is not any keyword. The actual keyword is 'else if'
                h.  'then' is not any keyword. therefore syntax error
                i.  ; should not be used after if condition. Therefore Logical Error
*/

/* SOLUTION C : */
/* a.  CALCULATION OF PROFIT OR LOSS *//*
int main()
{
    clrscr();
    int sp, cp, p_l;
    float perc;

    printf("Enter Cost Price of Item : ");
    scanf("%d",&cp);

    printf("\nEnter Sell Price of Item : ");
    scanf("%d",&sp);

    if(sp>cp)
    {
        p_l = sp - cp;
        perc = (float)p_l/(float)cp*100;
        printf("\nItem has PROFIT of Rs. %d with Profit Percentage %.2f",p_l,perc);
    }
    else if (cp>sp)
    {
        p_l = cp - sp;
        perc = (float)p_l/(float)cp*100;
        printf("\nItem has LOSS of Rs. %d with LOSS Percentage %.2f",p_l,perc);
    }
    else
    {
        printf("Item has no Profit/Loss");
    }

    printf("\n\n\nPress any key to exit.........");
    getch();
    return 0;
}*/

/* b. ODD OR EVEN NUMBER *//*
int main()
{
    clrscr();
    int num;

    printf("Enter a number to check : ");
    scanf("%d",&num);

    if(num % 2 == 0)
    {
        printf("\nThe number %d is an even number.",num);
    }
    else
    {
        printf("\nThe number %d is an odd number.",num);
    }

    printf("\n\n\n\nPress any key to exit.........");
    getch();
    return 0;
}*/

/* c. CHECK LEAP YEAR *//*
int main()
{
    clrscr();
    int year;

    printf("Enter the year to check for leap year : ");
    scanf("%d",&year);

    if(year % 400 == 0)
    {
        printf("\n%d Year is a Leap Year",year);
    }
    else if(year % 100 == 0)
    {
        printf("\n%d Year is not a Leap Year",year);
    }
    else if(year % 4 == 0)
    {
        printf("\n%d Year is a Leap Year",year);
    }
    else
    {
        printf("\n%d Year is not a Leap Year",year);
    }


    printf("\n\n\n\n\nPress any key to exit.........");
    getch();
    return 0;
}*/

/* d. FIND DAY ON 1st JANUARY OF ANY YEAR >1900 *//*
int main()
{
    clrscr();
    int year, ld=0,nd = 0, td = 0, day = 0 ;
    printf("Enter the required year : ");
    scanf("%d",&year);

    nd = (year-1900);
    for(int i=1900;i<year;i++)
    {
        if( ( i%4==0 && i%100!=0) || ( i%400==0 ))
            ld++;
    }
    td = nd + ld;// normal days + leap days
    day = td % 7;

    if(day == 0)
        printf("\nIt is Monday on 1st January %d",year);
    else if(day == 1)
        printf("\nIt is Tuesday on 1st January %d",year);
    else if(day == 2)
        printf("\nIt is Wednesday on 1st January %d",year);
    else if(day == 3)
        printf("\nIt is Thursday on 1st January %d",year);
    else if(day == 4)
        printf("\nIt is Friday on 1st January %d",year);
    else if(day == 5)
        printf("\nIt is Saturday on 1st January %d",year);
    else if(day == 6)
        printf("\nIt is Sunday on 1st January %d",year);

    printf("\n\n\n\nPress any key to exit.........");
    getch();
    return 0;
}*/

/* e. TO CHECK REVERSE OF 5 DIGIT NUMBER == ORIGINAL NUMBER*//*
int main()
{
    clrscr();
    int n,r,sum=0,t;

    printf("Enter a five digit number : ");
    scanf("%5d",&n);
    t=n;

    for(int i=0;i<5;i++)
    {
        r = n % 10;
        if(r)
            sum = sum * 10 + r;
        n = n / 10;
    }

    printf("\nReversed Number = %d and Original Number = %d\n",sum,t);

    if(t==sum)
        printf("\nOriginal Number == Reverse of Number");
    else
        printf("\nOriginal Number != Reverse of Number");

    printf("\n\n\n\nPress any key to exit.........");
    getch();
    return 0;
}*/

/* f. FIND YOUNGEST OF THREE *//*
int main()
{
    clrscr();
    int r,s,a,y;

    printf("Enter Age of Ram : ");
    scanf("%d",&r);
    printf("Enter Age of Shyam : ");
    scanf("%d",&s);
    printf("Enter Age of Ajay : ");
    scanf("%d",&a);

    printf("\nThe youngest of three is : ");

    if( r < s  || r < a)
    {
        if( r < s && r < a )
            printf("Ram.");
        else if(r==a)
            printf("Ram and Ajay.");
        else if(r==s)
            printf("Ram and Shyam.");
    }
    else if ( s < r || s < a )
    {
        if( s < r && s < a )
            printf("Shyam.");
        else if(s==a)
            printf("Shyam and Ajay.");
        else if(s==r)
            printf("Shyam and Ram.");
    }
    else if ( a < r || a < s )
    {
        if( a < s && a < r)
            printf("Ajay.");
        else if(a==r)
            printf("Ram and Ajay.");
        else if(a==s)
            printf("Ajay and Shyam.");
    }
    else if (s == r && r == a )
    {
        printf("All have same age.");
    }

    printf("\n\n\n\nPress any key to exit.........");
    getch();
    return 0;
}*/

/* g. CHECK IF A TRIANGLE IS VALID *//*-
int main()
{
    clrscr();
    int a1,a2,a3,sum=0;

    printf("Enter 1st angle (in degrees) : ");
    scanf("%3d",&a1);
    printf("Enter 2nd angle (in degrees) : ");
    scanf("%3d",&a2);
    printf("Enter 3rd angle (in degrees) : ");
    scanf("%3d",&a3);

    sum= a1 + a2 + a3;

    if(sum == 180)
        printf("\nThe given triangle is valid one.");
    else
        printf("\nThe given triangle is invalid.");

    printf("\n\n\n\nPress any key to exit.........");
    getch();
    return 0;
}*/

/* h. FIND AND STORE ABSOLUTE VALUE OF A NUMBER *//*
int main()
{
    clrscr();
    int num;
    unsigned int val;

    printf("Enter a number : ");
    scanf("%d",&num);

    val=num;

    if(num<0)
        val= -val;

    printf("Absolute value of number \"%d\" = %d ",num,val);

    printf("\n\n\n\nPress any key to exit.........");
    getch();
    return 0;
}*/

/* i. DETERMINE IF AREA > PERIMETER OF RECTANGLE *//*
int main()
{
    clrscr();
    int l,b,p,a;

    printf("Enter length of rectangle (in cm) : ");
    scanf("%d",&l);
    printf("Enter breadth of rectangle (in cm) : ");
    scanf("%d",&b);

    p=2*(l+b);
    a=l*b;

    printf("\nArea = %d square cm  and Perimeter = %d cm",a,p);

    if(a>p)
        printf("\nArea of rectangle is greater than its perimeter.");
    else
        printf("\nArea of rectangle is less than its perimeter.");

    printf("\n\n\n\nPress any key to exit.........");
    getch();
    return 0;
}*/

/* j. CHECK COLLINEAR POINTS IN 2-D CARTESIAN *//*
int main()
{
    clrscr();
    int x1,x2,x3,y1,y2,y3,s1,s2,s3;

    printf("Enter X1 : ");
    scanf("%d",&x1);
    printf("Enter Y1 : ");
    scanf("%d",&y1);
    printf("\nEnter X2 : ");
    scanf("%d",&x2);
    printf("Enter Y2 : ");
    scanf("%d",&y2);
    printf("\nEnter X3 : ");
    scanf("%d",&x3);
    printf("Enter Y3 : ");
    scanf("%d",&y3);

    s1=abs(x2-x1)/abs(y2-y1);
    s2=abs(x3-x1)/abs(y3-y1);
    s3=abs(x3-x2)/abs(y3-y2);

    if(s1==s2 && s2==s3)
        printf("\nThree points are collinear.");
    else
        printf("\nThree Points are non-collinear.");

    printf("\n\n\n\nPress any key to exit.........");
    getch();
    return 0;
}*/

/* k. CHECK POSITION OF POINT W.R.T. A CIRCLE *//*
int main()
{
    clrscr();
    float x,y,cx,cy,r,d1,d2;

    printf("Enter radius of circle : ");
    scanf("%f",&r);
    printf("\nEnter centre coordinates : ");
    scanf("%f %f",&cx,&cy);
    printf("\nEnter point coordinates : ");
    scanf("%f %f",&x,&y);


    d1 = abs(pow(x-cx,2) + pow(y-cy,2));
    d2 = abs(r*r);

    if(d1==d2)
        printf("\nPoint is on circle.");
    else if(d1<d2)
        printf("\nPoint is inside the circle.");
    else if(d1>d2)
        printf("\nPoint is outside the circle.");


    printf("\n\n\n\nPress any key to exit.........");
    getch();
    return 0;
}*/

/* l. COST PROFIT PROBLEM*//*
int main()
{
    clrscr();
    float x,y;

    printf("Enter Coordinates of the point : \n");
    scanf("%f %f",&x,&y);

    if(x==0 && y==0)
        printf("\nPoint lies at origin.");
    else if(x==0 && y!=0)
        printf("\nPoint lies on x-axis.");
    else if(x!=0 && y==0)
        printf("\nPoint lies on y-axis.");
    else
        printf("\nPoint does not lie at origin or any axis.");

    printf("\n\n\n\nPress any key to exit.........");
    getch();
    return 0;
}*/

/* SOLUTION D :
                a.  Dean of student affairs
                b.  Let Us C
                c.  w=1 x=0 y=1 z=1
                d.  y=1 z=1
                e.  Bennarivo
                f.  40
                g.  Definitely C !
                h.  1   1
                i.  z is big
                j.  -1  1
                k.  k=0
*/

/* SOLUTION E :
                a. No Error
                b. for Logical AND && is used while for bitwise AND & is used
                c. For the purpose of logical OR, || is used . So writing " or " is wrong as it is not a keyword
                d. The whole if condition must be inside a Parenthesis
                e. For the purpose of logical OR, && is used . So writing " and " is wrong as it is not a keyword
                f. For Logical AND && is used while for bitwise AND & is used
                g. ; is not used after if expression
                h. No Error
*/

/* SOLUTION F : */
/* a. CHECK FOR A LEAP YEAR *//*
int main(void)
{
    clrscr();
    int year;

    printf("Enter a year : ");
    scanf("%d",&year);

    if((year%4==0) && (year%100!=0) || (year%400==0))
    {
        printf("\n%d Year is a leap year.",year);
    }
    else
    {
        printf("\n%d Year is not a leap year.",year);
    }

    printf("\n\n\n\n............Press any key to exit............\n\n\n\n");
    getch();
    return 0;
}*/

/* b. TO CHECK INPUT CHARACTER *//*
int main(void)
{
    clrscr();
    char ch;

    printf("Enter a character : ");
    scanf("%c",&ch);

    if(ch>=65 && ch<=90)
    {
        printf("\n\"%c\" Character entered is a CAPITAL LETTER.",ch);
    }
    else if (ch>=97 && ch<=122)
    {
        printf("\n\"%c\" Character entered is a SMALL CASE LETTER.",ch);
    }
    else if (ch>=48 && ch<=57)
    {
        printf("\n\"%c\" Character entered is a DIGIT FROM 0 TO 9.",ch);
    }
    else if(ch<=127)
    {
        printf("\n\"%c\" Character entered is a SPECIAL SYMBOL.",ch);
    }
    else
    {
        printf("\n\"%c\" Character entered is an INVALID CHARACTER OF UNKNOWN TYPE.",ch);
    }

    printf("\n\n\n\n............Press any key to exit............\n\n\n\n");
    getch();
    return 0;
}*/

/* c. TO CHECK PERSON ELIGIBILITY FOR INSURANCE OF A COMAPNY *//*
int main(void)
{
    clrscr();
    int age,g_s=0,r_s=0;
    char gender,ras,hs,ch='N';
    // ras = Residential Area Status
    // hs = Health Status
    printf("Enter Person's Details : ");

    printf("\nEnter Gender ( Male(M)/Female(F)/Other) : ");
    scanf(" %c",&gender);
    if(gender == 'M' || gender == 'm')
    {
        g_s=1;
    }
    else if(gender == 'F' || gender == 'f')
    {
        g_s=2;
    }
    else
    {
        g_s=0;
    }

    printf("\nEnter Residential Area ( City(U)/Village(V)/Other ) : ");
    scanf(" %c",&ras);
    if(ras == 'U' || ras == 'u' || ras == 'v' || ras == 'V')
    {
        r_s=1;
    }
    else if(ras == 'v' || ras == 'V')
    {
        r_s=2;
    }
    else
    {
        r_s=0;
    }

    printf("\nEnter Health Status ( Excellent(E)/Poor(P)/Other ) : ");
    scanf(" %c",&hs);

    printf("\nEnter Age : ");
    scanf("%d",&age);

    printf("\n\n\n\n****** Insurance Eligibility ****** ");

    if( (hs=='E' || hs=='e') && (age>=25 && age<=35) && g_s==1 && r_s==1)
    {
        printf("\nWhether can be insured ? : Yes ");
        printf("\nPremium Rate : Rs. 4 per Thousand ");
        printf("\nMaximum Amount of Insuarnce : 2 Lakh Rupees ");
    }
    else if((hs=='E' || hs=='e') && (age>=25 && age<=35) && g_s==2 && r_s==1)
    {
        printf("\nWhether can be insured ? : Yes ");
        printf("\nPremium Rate : Rs. 3 per Thousand ");
        printf("\nMaximum Amount of Insuarnce : 1 Lakh Rupees ");
    }
    else if((hs=='P' || hs=='p') && (age>=25 && age<=35) && g_s==1 && r_s==2)
    {
        printf("\nWhether can be insured ? : Yes ");
        printf("\nPremium Rate : Rs. 6 per Thousand ");
        printf("\nMaximum Amount of Insuarnce : Rs. 10000");
    }
    else
    {
        printf("\nWhether can be insured ? : NO ");
        printf("\nPremium Rate : NOT APPLICABLE ");
        printf("\nMaximum Amount of Insuarnce : NOT APPLICABLE");
    }

    printf("\n\n\n\n............Press any key to exit............\n\n\n\n");
    getch();
    return 0;
}*/

/* d. CHECK STEEL GRADE *//*
int main(void)
{
    clrscr();
    float hard,ts,cc;
    int c1=0,c2=0,c3=0;

    printf("Enter following details of Steel under Consideration : \n");
    printf("\nCarbon Content : ");
    scanf("%f",&cc);
    printf("\nTensile Strength : ");
    scanf("%f",&ts);
    printf("\nHardness : ");
    scanf("%f",&hard);

    if(hard>50)
        c1=1;
    if(cc<0.7)
        c2=1;
    if(ts>5600)
        c3=1;


    if(c1==1 && c2==1 && c3==1 )
    {
        printf("\nGrade Quality of Steel : 10");
    }
    else if (c1==1 && c2==1 && c3==0)
    {
        printf("\nGrade Quality of Steel : 09");
    }
    else if (c1==0 && c2==1 && c3==1)
    {
        printf("\nGrade Quality of Steel : 08");
    }
    else if(c1==1 && c2==0 && c3==1)
    {
        printf("\nGrade Quality of Steel : 07");
    }
    else if(c1==1 || c2==1 || c3==1)
    {
        printf("\nGrade Quality of Steel : 06");
    }
    else
    {
        printf("\nGrade Quality of Steel : 05");
    }

    printf("\n\n\n\n............Press any key to exit............\n\n\n\n");
    getch();
    return 0;
}*/

/* e. LIBRARY LATE FINE CALCULATION *//*
int main(void)
{
    clrscr();
    int days;
    float total;

    printf("Enter No. of days the book is returned Late : ");
    scanf("%d",&days);

    if(days>30)
    {
        printf("\nMembership of Defaulter stands Cancelled.");
    }
    else if (days<=30 && days>10)
    {
        total=10*days;
        printf("\nTotal Fine on late return of book : Rs. %.2f",total);
    }
    else if (days<=10 && days>5)
    {
        total=1*days;
        printf("\nTotal Fine on late return of book : Rs. %.2f",total);
    }
    else if (days<=5 && days>0)
    {
        total=0.50*days;
        printf("\nTotal Fine on late return of book : Rs. %.2f",total);
    }
    else if(days<=0)
    {
        printf("\nThe book is not late. Therefore No Late Fine.");
    }

    printf("\n\n\n\n............Press any key to exit............\n\n\n\n");
    getch();
    return 0;
}*/

/* f. CHECK IF TRIANGLE IS VALID OR NOT USING SIDES *//*
int main(void)
{
    clrscr();
    int s1,s2,s3,ls,sum;

    printf("Enter Three Sides of the triangle (in cm) : \n");
    printf("Side 1 : ");
    scanf("%d",&s1);
    printf("Side 2 : ");
    scanf("%d",&s2);
    printf("Side 3 : ");
    scanf("%d",&s3);

    if(s1 > s2)
    {
        if(s1>s3)
        {
            sum=s2+s3;
            ls=s1;
        }
        else
        {
            ls=s3;
            sum=s1+s2;
        }
    }
    else
    {
        if(s2>s3)
        {
            ls=s2;
            sum=s1+s3;
        }
        else
        {
            ls=s3;
            sum=s1+s2;
        }
    }

    if(sum>ls)
    {
        printf("\nThe triangle is a valid one.");
    }
    else
    {
        printf("\nThe triangle is invalid.");
    }

    printf("\n\n\n\n............Press any key to exit............\n\n\n\n");
    getch();
    return 0;
}*/

/* g. TO CHECK TYPE OF TRIANGLE *//*

int main(void)
{
    clrscr();
    int s1,s2,s3,ls,sum,b,p;

    printf("Enter Three Sides of the triangle (in cm) : \n");
    printf("Side 1 : ");
    scanf("%d",&s1);
    printf("Side 2 : ");
    scanf("%d",&s2);
    printf("Side 3 : ");
    scanf("%d",&s3);

    if(s1 > s2)
    {
        if(s1>s3)
        {
            sum=s2+s3;
            ls=s1;
            b=s2;p=s3;
        }
        else
        {
            ls=s3;
            sum=s1+s2;
            b=s2;p=s1;
        }
    }
    else
    {
        if(s2>s3)
        {
            ls=s2;
            sum=s1+s3;
            b=s1;p=s3;
        }
        else
        {
            ls=s3;
            sum=s1+s2;
            b=s2;p=s1;
        }
    }

    if(sum>ls)
    {
        if(s1!=s2 && s2!=s3 && s1!=s3)
        {
            printf("\nScalene Triangle.");
        }
        else if(s1==s2 && s2==s3 && s1==s3)
        {
            printf("\nEquilateral Triangle.");
        }
        else if( (s1==s2 && s3!=s1) || (s1==s3 && s2!=s1) || (s3==s2 && s3!=s1) )
        {
            printf("\nIsosceles Triangle.");
        }


        if((ls*ls)==(b*b + p*p))
        {
            printf("\nRight Angled Triangle.");
        }
        else
        {
            printf("\nNot a right angled triangle.");
        }
    }
    else
    {
        printf("\nThe triangle is invalid.");
    }

    printf("\n\n\n\n............Press any key to exit............\n\n\n\n");
    getch();
    return 0;
}*/

/* h. CHECK EFFICIENCY OF A WORKER IN A COMAPNY *//*
int main(void)
{
    clrscr();
    float hours;

    printf("Enter time taken by worker for the work (in hours) : \n");
    scanf("%f",&hours);

    if(hours>5.0)
    {
        printf("\nWorker should leave the Company.");
    }
    else if(hours<=5.0 && hours>4.0)
    {
        printf("\nWorker should be given training to improve his speed.");
    }
    else if(hours<=4.0 && hours>3)
    {
        printf("\nWorker should be ordered to improve his speed.");
    }
    else if(hours<=3.0 && hours>2)
    {
        printf("\nWorker is highly efficient.");
    }
    else if(hours<=2.0 && hours>0.0)
    {
        printf("\nWorker is unbelievable. Far Efficient.");
    }
    else
    {
        printf("\nInvalid Hours Input. Please run again.");
    }

    printf("\n\n\n\n............Press any key to exit............\n\n\n\n");
    getch();
    return 0;
}*/

/* i. CHECK PASSING CRITERIA OF UNIVERSITY *//*
int main(void)
{
    clrscr();
    float perA, perB;

    printf("Enter marks in Main Subject A (in percent) : ");
    scanf("%f",&perA);

    printf("\nEnter marks in Subsidiary Subject B (in percent) : ");
    scanf("%f",&perB);

    if( (perA>=55 && perB>=45) || (perA<55 && perA>=45 && perB>=55) )
    {
        printf("\n\n\nCongratulations.............\nThe Student has passed.....");
    }
    else if(perB<45 && perA>=65)
    {
        printf("\n\n\nThe student is allowed to re-appear in Examination of Subject B.");
    }
    else if(perA>=0 && perB>=0)
    {
        printf("\n\n\nThe student has failed in examinations.");
    }
    else
    {
        printf("\n\n\nInvalid Marks Percentage Input. Please run again.");
    }

    printf("\n\n\n\n............Press any key to exit............\n\n\n\n");
    getch();
    return 0;
}*/

/* j. IMPLEMENT COMPANY POLICY FOR PROCESSING CUSTOMER ORDER *//*
int main(void)
{
    clrscr();
    long int stock, order;
    int credit=0;

    printf("Enter the no. of items in stock : ");
    scanf("%ld",&stock);

    printf("\nEnter the no. of items in order : ");
    scanf("%ld",&order);

    printf("\nEnter the credit status of order ( OK(1)/NOT OK (0) ) : ");
    scanf("%d",&credit);

    if(credit==1 && order<stock && order>0 && stock>0)
    {
        printf("\n\n\nItems Required Sent.\nCustomer Intimation : \n\t\tYour Order is processed and will be delivered very soon.\n\t\tThank you. :)");
    }
    else if(credit!=1 && order>0 && stock>0)
    {
        printf("\n\n\nPoor Credit Status.\nCustomer Intimation : \n\t\tYour Credit Status with us is NOT GOOD. So your order will not be processed.\n\t\tImprove credit status.\n\t\tThank you. :[ ");
    }
    else if(credit==1 && order>stock && order>0 && stock>0)
    {
        printf("\n\n\nAvailable supplies sent. Rest will be sent when available.");
        printf("\nCustomer Intimation :\n\t\tYour Order has been processed and supplies as available in stock has sent for delivery.\n\t\tRest of supplies will be sent soon.\n\t\tThank you. :)");
    }
    else
    {
        printf("\n\n\nInvalid Input(s). Please run again.");
    }

    printf("\n\n\n\n............Press any key to exit............\n\n\n\n");
    getch();
    return 0;
}*/


/* SOLUTION G :
                a.  Unpredictable because "num" variable not initialized and will contain garbage value.
                b.  30
                c.  Welcome
*/

/* SOLUTION H :
                a.  Missing colon :
                b.  Garbage character for %c
                c.  No error
                d.  Missing colon :
                e.  semi-colon ; is not used in ternary operator
                f.  Incorrect syntax for ternary operator
                g.  No Error
*/

/* SOLUTION I :
                a.
                    main()
                    {
                        int x, min, max ;
                        scanf ( "\n%d %d", &max, &x ) ;
                        (x>max)?(max=x):(min=x);
                    }
                b.
                    main( )
                    {
                        int code ;
                        scanf ( "%d", &code ) ;
                        (code>1) ? printf("\nJerusalem") : ( (code<1) ? printf ("\nEddie") : printf ( "\nC Brain" ));
                    }
                c.
                    main( )
                    {
                        float sal ;
                        printf ("Enter the salary" ) ;
                        scanf ( "%f", &sal ) ;
                        ( sal < 40000 && sal > 25000 ) ? printf ( "Manager" ) : ( ( sal < 25000 && sal > 15000 ) ? printf ( "Accountant" ) : printf ( "Clerk" ));
                    }
*/

/* SOLUTION J : */
/* a. USING TERNARY OPERATOR CHECK LOWER CASE OR SPECIAL SYMBOL *//*
int main(void)
{
    clrscr();
    char ch;

    printf("Enter a character : ");
    scanf(" %c",&ch);

    (ch>=97 && ch<=122) ? printf("\nLower Case Character.") : printf("\nNot a Lower Case Character");

    ( (ch>=0 && ch<=47) || (ch>=58 && ch<=64) || (ch>=91 && ch<=96) || (ch>=123) ) ? printf("\nSpecial Symbol") : printf("\nNot a special Symbol");

    printf("\n\n\n\n............Press any key to exit............\n\n\n\n");
    getch();
    return 0;
}*/

/* b. USING CONDITIONAL OPERATOR CHECK LEAP YEAR OR NOT *//*
int main(void)
{
    clrscr();
    int year;

    printf("Enter a Year : ");
    scanf("%d",&year);

    ( (year%4==0 && year%100!=0) || (year%400==0) ) ? printf("\n%d is Leap Year.",year) : printf("\n%d is Not Leap Year",year);

    printf("\n\n\n\n............Press any key to exit............\n\n\n\n");
    getch();
    return 0;
}*/

/* c. GREATEST OF THREE NUMBER USING CONDITIONAL OPERATOR *//*
int main(void)
{
    clrscr();
    int n1,n2,n3;

    printf("Enter three numbers : \n");
    scanf("%d %d %d",&n1,&n2,&n3);

    printf("\nGreatest Number : ");

    n1>n2 ? (n1>n3 ? printf("%d",n1) : printf("%d",n3)) : (n2>n3 ? printf("%d",n2) : printf("%d",n3));

    printf("\n\n\n\n............Press any key to exit............\n\n\n\n");
    getch();
    return 0;
}*/

/* **************************** END OF CHAPTER *********************** */
