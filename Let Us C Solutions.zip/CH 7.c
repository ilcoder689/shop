#include<stdio.h>
#include<conio.h>
#include<string.h>
#include<stdlib.h>
#include<math.h>
void clrscr(){system("cls || clear");}
long long int power(float k, long int l) {float i=l,res=1.0; while(i-->0)res=res*k; return res; }

/*-------------CH : THE C PREPROCESSOR ---------------- */

/* SOLUTION A :
                a.  a preprocessor directive is a message from programmer to the preprocessor
                b.  #define SQR(X) ( X * X )
                c.  1.  FALSE
                    2.  COMPILER DEPENDENT ; USUALLY TRUE
                    3.  TRUE
                    4.  FALSE
                    5.  FALSE
                    6.  FALSE
                d.  Any number of #define directive can be there in a program
                e.  #include"conio.h" searches for the file in current directory as well as specified list of directories
                    while #include<conio.h> searches for the file in specified list of directories only.
                f.  A header file is A file that contains definitions and macros
                g.  #elseif is not any pre-processor directive.
                h.  All macro substitutions in a program are done before compilation of program
                i.  In a program the statement:
                    #include "filename"
                    is replaced by the contents of the file �filename� before compilation
*/

/* SOLUTION B :
                a.  2
                b.  7   as PRODUCT(i+1) expands to i+1*i+1 = i+(1*i)+1
                c.  12  49 (Undefined behaviour)
                d.  Error
*/

/* SOLUTION C : */
/*  a.  MACROS FORMATION #1 *//*

#define ISSMALL(x) (x>=97 && x<=122 ? 1 : 0)
#define ISUPPER(x) (x>=65 && x<=90 ? 1 : 0)
#define ISALPHABET(x) (ISSMALL(x) || ISUPPER(x) ? 1 : 0)
#define BIG(x,y) (x>y ? x : y)

int main()
{
    clrscr();
    int a,b,d;
    char c;

    printf("Enter character : ");
    scanf(" %c",&c);

    if(d=ISALPHABET(c) == 1)
    {
      if(d=ISUPPER(c)==1)
            printf("\nYou entered a CAPITAL case alphabet.");
      else
        printf("\nYou entered a SMALL case alphabet.");
    }
    else
        printf("\nYou did not entered an alphabet.");

    printf("\nEnter two numbers : ");
    scanf("%d%d",&a,&b);
    d=BIG(a,b);
    printf("\nThe bigger is %d.",d);

    printf("\n\n\n\nPress any key to exit..................");
    getch();
    return 0;
}*/

/*  b.  MACROS FORMATION #2 *//*
/*  areaperi.h  *//*
#define AREAT(b,h) (0.5 * b * h)
#define AREAC(r) (3.14 * r * r)
#define AREAS(a) (a*a)
#define PERIT(a1,a2,a3) (a1+a2+a3)
#define PERIS(a) (4*a)
#define PERIC(r) (2 * 3.14 * r)

int main()
{
    clrscr();
    float r,a,b,h,x,y,z;

    printf("Enter radius of circle : ");
    scanf("%f",&r);
    printf("\nCircle :\tPerimeter = %.2f\tArea = %.2f",PERIC(r),AREAC(r));

    printf("\n\nEnter Side of square : ");
    scanf("%f",&a);
    printf("\nSquare :\tPerimeter = %.2f\tArea = %.2f",PERIS(a),AREAS(a));

    printf("\n\nEnter base, height , side1, side2, side3 : ");
    scanf("%f%f%f%f%f",&b,&h,&x,&y,&z);
    printf("\nTriangle :\tPerimeter = %.2f\tArea = %.2f",PERIT(x,y,z),AREAT(b,h));

    printf("\n\n\n\nPress any key to exit..................");
    getch();
    return 0;
}*/

/*  c.  MACROS FORMATION #3 *//*
#define AM(x,y) ((x+y)/2)
#define AV(x) (x>0 ? x : (-x))
#define CONVERT(x) (x>=65 && x<=90 ? x+32 : x)
#define BIG(x,y) (x>y ? x : y)

int main()
{
    clrscr();
    int c;
    float a,b;
    char ch;

    printf("Enter a character to convert to lower case : ");
    scanf(" %c",&ch);
    printf("After conversion , %c",CONVERT(ch));
    fflush(stdin);

    printf("\n\nEnter a number to find absolute value : ");
    scanf("%d",&c);
    printf("Absolute value =  %d",AV(c));

    printf("\n\nEnter two numbers : ");
    scanf("%f%f",&a,&b);
    printf("Arithmetic Mean =  %.2f\tBigger = %.0f",AM(a,b),BIG(a,b));


    printf("\n\n\n\nPress any key to exit..................");
    getch();
    return 0;
}*/

/*  d.  MACROS FORMATION #4 *//*
#define INTEREST(p,r,y) (p*r*y/100)
#define VALUE(p,r,y) (p+INTEREST(p,r,y))

int main()
{
    clrscr();
    float p,r,y;

    printf("Enter Principal amount , rate of interest (%%) and years  : ");
    scanf("%f%f%f",&p,&r,&y);
    printf("\nINTEREST = %.2f and VALUE = %.2f",INTEREST(p,r,y),VALUE(p,r,y));

    printf("\n\n\n\nPress any key to exit..................");
    getch();
    return 0;
}*/

/* ------------------------ END OF CHAPTER ------------------------ */
