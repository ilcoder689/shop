#include<stdio.h>
#include<conio.h>
#include<string.h>
#include<stdlib.h>
#include<math.h>
void clrscr(){system("cls || clear");}
long long int power(float k, long int l) {float i=l,res=1.0; while(i-->0)res=res*k; return res; }

/*-------------CH : DATA TYPES REVISITED ---------------- */

/* SOLUTION A :
                a.  0 - 50000 numbers will get printed
                b.  13.500000   13.500000
                c.  main's i = 0
                    val's i = 100
                    main's i = 101
                    val's i = 100
                d.  6   5   6
                e.  count = 5
                    count = 4
                    count = 3
                    count = 2
                    count = 1
                f.  6   9   13  18
                g.  4.500000     14.800000
                h.  1   1   1
                    1   1   2
                i.  30      20
*/

/* SOLUTION B :
                a.  No Error
                b.  No Error
                c.  Wrong format specifier used.
                d.  Incorrect declarations
                e.  No Error
                f.  No Error
*/

/* SOLUTION C :
                a.  True
                b.  True
                c.  False
                d.  False
                e.  True
                f.  True
                g.  False
                h.  False
                i.  False
                j.  False
                k.  True
*/

/* SOLUTION D :
We need to initialize sum with 0 (zero) only once and we want it to retain its value during recursion. Hence sum is initialized as static variable. */
