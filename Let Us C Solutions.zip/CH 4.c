#include<stdio.h>
#include<conio.h>
#include<string.h>
#include<stdlib.h>
#include<math.h>
void clrscr(){system("cls || clear");}

/*-------------CH : THE CASE CONTROL STRUCTURE ---------------- */

/* SOLUTION A :
                a.  Heart
                    I thought one wears a suite
                b.  I am in case 3
                c.  Pure simple egghead
                d.  Customers are dicey
                    Markets are pricey
                    Investors are moody
                    At least employees are good
                e.  Trapped
                f.  You entered a and b
                g.  Feeding fish
                    Weeding grass
                    mending roof
                    Just to survive
*/

/* SOLUTION B :
                a.  : colon is used after case, not semicolon ; ALSO ; shouldn't be used after switch
                b.  Relational operator can;t be used in case. break statement is not used. Logical error
                c.  Float can not be used in switch-case
                d.  Logical operators can't be used in case. It must be a constant.
*/

/* SOLUTION C : */
/* MENU DRIVEN PROGRAM FOR
                            1. FACTORIAL OF NUMBER
                            2. PRIME OR NOT
                            3. EVEN OR ODD
                            4. EXIT
*//*
int main(void)
{
    clrscr();
    int ch=5,num,i;
    float fact=1;

    while(1)
    {
        clrscr();
        printf(" ------------ WELCOME TO THE MENU ------------ \n\n");

        printf("Please select an option below : - ");
        printf("\n1. Factorial");
        printf("\n2. Check whether Prime or not");
        printf("\n3. Check whether Even or Odd");
        printf("\n4. Exit");

        printf("\n\nEnter your choice : ");
        scanf("%d",&ch);

        fflush(stdin);

        switch(ch)
        {
        case 1 :
            printf("\nEnter a Number : ");
            scanf("%d",&num);
            for(i=num;i>0;i--)
                fact=fact*i;
            printf("\n %d ! = %.0f",num,fact);
            break;

        case 2 :
            printf("\nEnter a Number : ");
            scanf("%d",&num);
            for(i=2;i<=num/2;i++)
                {
                    if(num%i==0)
                    {
                        printf("\n%d is Not a Prime Number.",num);
                        break;
                    }
                    else
                        printf("\n%d is a prime number.",num);
                }
            break;

        case 3 :
            printf("\nEnter a Number : ");
            scanf("%d",&num);
            if(i%2==0)
                printf("\n%d is an even number.",num);
            else
                printf("\n%d is an odd number.",num);
            break;

        case 4 :
            printf("\nPress any key to exit.");
            getch();
            return 0;

        default :
            printf("\nInvalid Input. Please try again.");
        }

            printf("\n\nPress any key to start again..");
            getch();
    }
}*/

/* SOLUTION D : FINDING GRACEMARKS OF STUDENT USING SWITCH *//*
int main(void)
{
    clrscr();
    int cls,sc,ch=4;

    while(1)
    {
        clrscr();
        printf(" ------------ WELCOME TO THE MENU ------------ \n\n");

        printf("Please select an option below : - ");
        printf("\n1. Exit(1)");
        printf("\n2. Proceed (2) ");

        printf("\n\nEnter your choice : ");
        scanf("%d",&ch);

        switch(ch)
        {
        case 1 :
            printf("\nPress any key to exit.");
            getch();
            return 0;

        case 2 :
            while(1)
            {
                printf("\nEnter class of student ( First(1) / Second(2) / Third(3) : ");
                scanf("%u",&cls);
                printf("\nEnter Count of subjects in which student has failed : ");
                scanf("%u",&sc);

                if(cls>3 || cls<1)
                {
                    printf("\nInvalid Class Input. Please Enter again.\n");
                    continue;
                }

                switch(cls)
                {
                case 1 :
                    if(sc>3)
                        printf("\nNO GRACE MARKS.\n");
                    else
                        printf("\nGRACE MARKS PER SUBJECT = 5.\nTOTAL GRACE MARKS = %u.\n",sc*5);
                    break;

                case 2 :
                    if(sc>2)
                        printf("\nNO GRACE MARKS.\n");
                    else
                        printf("\nGRACE MARKS PER SUBJECT = 4.\nTOTAL GRACE MARKS = %u.\n",sc*4);
                    break;

                case 3 :
                    if(sc>1)
                        printf("\nNO GRACE MARKS.\n");
                    else
                        printf("\nGRACE MARKS PER SUBJECT = 5.\nTOTAL GRACE MARKS = %u.\n",sc*5);
                    break;

                default :
                    printf("\nInvalid class input. Please try again.\n");
                    continue;
                }

                printf("\nPress any key to start again..\n");
                getch();
                break;
            }
        default :
            printf("\nInvalid Input.\n");
            fflush(stdin);
            getch();
        }
    }
}*/

/* ************************ END OF CHAPTER ************************ */
