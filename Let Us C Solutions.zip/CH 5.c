#include<stdio.h>
#include<conio.h>
#include<string.h>
#include<stdlib.h>
#include<math.h>
void clrscr(){system("cls || clear");}
long long int power(float k, long int l) {float i=l,res=1.0; while(i-->0)res=res*k; return res; }

/*-------------CH : FUNCTIONS AND POINTERS ---------------- */

/* SOLUTION A :
                a.  Both messages gets printed indefinigtely
                b.  "C to it that C survives" prints indefinitely
                c.  100
                d.  function multiply() not defined
*/

/* SOLUTION B :
                a.  A function can't return two values using "return"
                b.  No Error
                c.  a,ch variables are not defined in function printit()
                d.  ; is not used after parenthesis during function definition
                e.  Error because a function shouldn't be defined inside another function without return type else it will be treated as function call
                f.  Error , message() function can't accept any parameter
*/

/* SOLUTION C :
                a.  No, because function definition syntax is incorrect
                b.  1.  False
                    2.  False
                    3.  True
                    4.  False
                    5.  True
                    6.  True
                    7.  True
                    8.  False
                    9.  True
                    10. False
*/

/* SOLUTION D : */
/* a.   FUNCTION TO CALUCLATE FACTORIAL OF A NUMBER *//*
float factorial (int);
int main(void)
{
    clrscr();
    int num;

    printf("------------------------------ FUNCTION FOR FACTORIAL OF A NUMBER ------------------------------\n\n");

    printf("Enter a number : ");
    scanf("%d",&num);

    printf("\n%d ! = %.2f or %e\n",num,factorial(num),factorial(num));

    printf("\n\n\n\nPress any key to exit..............");
    getch();
    return 0;
}
float factorial (int i)
{
    if(i==0)
        return 1;
    return i*factorial(i-1);
}*/

/* b.   FUNCTION TO CALCULATE POWER OF A NUMBER *//*
float power (float,int);
int main(void)
{
    clrscr();
    float num;
    int p;

    printf("------------------------------ FUNCTION FOR POWER OF A NUMBER ------------------------------\n\n");

    printf("Enter a number : ");
    scanf("%f",&num);
    printf("Enter the power : ");
    scanf("%d",&p);

    printf("\n%.2f ^ %d = %.2f or %e\n",num,p,power(num,p),power(num,p));

    printf("\n\n\n\nPress any key to exit..............");
    getch();
    return 0;
}
float power (float i,int j)
{
    if(j==0)
        return 1;
    return i*power(i,j-1);
}*/

/* c.   FUNCTION TO CONVERT YEAR INTO ROMAN *//*
void roman (int);
int main(void)
{
    clrscr();
    int year;

    printf("------------------------------ FUNCTION FOR ROMAN OF A YEAR ------------------------------\n\n");

    printf("Enter a year : ");
    scanf("%d",&year);

    printf("\n%d Year = ",year);

    roman(year);

    printf("\n\n\n\nPress any key to exit..............");
    getch();
    return 0;
}
void roman (int i)
{
    int j;
    if(i==0)
        return ;

    if(i>=1000)
    {
        j=i/1000;
        while((j--)>0)
            printf("m");
        return roman(i%1000);
    }

    else if(i>=500)
    {
        j=i/500;
        while((j--)>0)
            printf("d");
        return roman(i%500);
    }

    else if(i>=100)
    {
        j=i/100;
        while((j--)>0)
            printf("c");
        return roman(i%100);
    }

    else if(i>=50)
    {
        j=i/50;
        while((j--)>0)
            printf("l");
        return roman(i%50);
    }

    else if(i>=10)
    {
        j=i/10;
        while((j--)>0)
            printf("x");
        return roman(i%10);
    }

    else if(i==9)
    {
        printf("ix");
        return roman(i%9);
    }

    else if(i>=5)
    {
        j=i/5;
        while((j--)>0)
            printf("v");
        return roman(i%5);
    }

    else if(i==4)
    {
        printf("iv");
        return roman(i%4);
    }

    else if(i>=1)
    {
        j=i/1;
        while((j--)>0)
            printf("i");
        return roman(i%1);
    }
}*/

/* d.   FUCNTION TO CHECK LEAP YEAR *//*
void check (int);
int main(void)
{
    clrscr();
    int year;

    printf("------------------------------ FUNCTION FOR CHECKING A LEAP YEAR ------------------------------\n\n");

    printf("Enter a year : ");
    scanf("%d",&year);

    check(year);

    printf("\n\n\n\nPress any key to exit..............");
    getch();
    return 0;
}
void check (int i)
{
    if( (i%4==0 && i%100!=0) || i%400==0 )
        printf("\n%d is a Leap Year.",i);
    else
        printf("\n%d is not a leap year.",i);
}*/

/* e.   FUNCTION TO OBTAIN PRIME FACTORS *//*
void check (int);
int main(void)
{
    clrscr();
    int num;

    printf("------------------------------ FUNCTION TO OBTAIN PRIME FACTORS ------------------------------\n\n");

    printf("Enter a number : ");
    scanf("%d",&num);

    printf("\nPrime factors of %d are : ",num);

    check(num);

    printf("\n\n\n\nPress any key to exit..............");
    getch();
    return 0;
}
void check (int i)
{
    int j=2;

    while(1)
    {
        if(i==1)
        {
            break;
        }
        if(i%j==0)
        {
            if(i==j)
                printf("%d",j);
            else
                printf("%d * ",j);
            i=i/j;
        }
        else
        {
            j++;
        }
    }
}*/

/* SOLUTION E :
                a.  3.000000
                b.  Error
*/

/* SOLUTION F : */
/* a.   GIVEN PROBLEM #1 *//*
float mult (float,int);
int main(void)
{
    clrscr();
    int num;
    float n;

    printf("Enter the integer : ");
    scanf("%d",&num);
    printf("Enter the float : ");
    scanf("%f",&n);

    printf("\n%d * %.2f = %.2f ",num,n,mult(n,num));

    printf("\n\n\n\nPress any key to exit..............");
    getch();
    return 0;
}
float mult (float j,int i)
{
    float t = j*i;

    return t;
}*/

/* b.   GIVEN PROBLEM #2 *//*
void func (int *, float *, float *);
int main(void)
{
    clrscr();
    int sum;
    float sd,avg;

    func(&sum,&avg,&sd);

    printf("\nSum = %d\nAverage = %.2f\nStandard Deviation = %.2f\n",sum,avg,sd);

    printf("\n\n\n\nPress any key to exit..............");
    getch();
    return 0;
}
void func (int *i,float * j,float *k)
{
    int n1,n2,n3,n4,n5;

    printf("\nEnter 5 integers : ");
    scanf("%d %d %d %d %d",&n1,&n2,&n3,&n4,&n5);

    *i=n1+n2+n3+n4+n5;
    *j=*i/5;
    *k= sqrt( ( pow(n1-*j,2) + pow(n2-*j,2)+ pow(n3-*j,2) +pow(n4-*j,2) +pow(n5-*j,2) ) / 4 );
}*/

/* c.   GIVEN PROBLEM #3 *//*
void func (float *, float *);
int main(void)
{
    clrscr();
    float per,avg;

    func(&avg,&per);

    printf("\nAverage = %.2f\nPercentage = %.2f %%\n",avg,per);

    printf("\n\n\n\nPress any key to exit..............");
    getch();
    return 0;
}
void func (float * j,float *k)
{
    int n1,n2,n3,i;

    printf("\nEnter 3 Subject's Marks : \n");
    scanf("%d %d %d",&n1,&n2,&n3);

    i=n1+n2+n3;
    *j=i/3;
    *k= (i/300.0)*100;
}*/

/* SOLUTION G :
                a.  5   2
                b.  25  4
                c.  16  2
                d.  1006    1006    1006
                    13.500000   13.500000   13.500000   13.500000   13.500000
*/

/* SOLUTION H :
                a.  Wrong braces
                b.  In function definition the variable in formal parameter should be a pointer
                c.  "m" should be declared first in parameters
                d.  No error if correct prototype is there for function returning pointer
*/

/* SOLUTION I :
                a.  C adds wings to your thoughts
                b.  1   2   3   4   5
*/

/* SOLUTION J : */
/* a.   FUNCTION TO FIND SUM OF DIGITS OF NUMBER *//*
int rec(int);
int wrec(int);
int main(void)
{
    clrscr();
    int num;

    printf("------------ FUNCTION TO FIND SUM OF DIGITS OF NUMBER ------------\n\n");

    printf("Enter any number : ");
    scanf("%d",&num);

    printf("\n\nWithout recursion, sum of digits of number \"%d\" : %d",num,wrec(num));
    printf("\nWith recursion, sum of digits of number \"%d\" : %d",num,rec(num));

    printf("\n\n\n\nPress any key to exit................");
    getch();
    return 0;
}
int rec(int k)
{
    static int r,sum=0;

    if(k==0)
        return 0;

    r=k%10;
    k=k/10;

    return (sum+r+rec(k));
}
int wrec(int k)
{
    int r1,sum1=0;

    for(int i=k;i>0;i=i/10)
    {
        r1 = i % 10;
        sum1 = sum1 + r1;
    }

    return sum1;
}*/

/* b.   FUNCTION TO FIND PRIME FACTORS OF A NUMBER *//*
void rec(int);
void wrec(int);
int main(void)
{
    clrscr();
    int num;

    printf("------------ FUNCTION TO FIND PRIME FACTORS OF A NUMBER ------------\n\n");

    printf("Enter any number : ");
    scanf("%d",&num);

    printf("\n\nWithout recursion, prime factors of number \"%d\" : ",num);
    wrec(num);
    printf("\nWith recursion, prime factors of number \"%d\" : ",num);
    rec(num);

    printf("\n\n\n\nPress any key to exit................");
    getch();
    return 0;
}
void rec(int m)
{
    static int j=2;

    if(m==1)
        return ;

    if(m%j==0)
    {
        if(m==j)
            printf("%d",j);
        else
            printf("%d * ",j);
        m=m/j;
    }
    else
    {
        j++;
    }

    rec(m);
}

void wrec(int i)
{
    int k=2;

    while(1)
    {
        if(i==1)
        {
            break;
        }
        if(i%k==0)
        {
            if(i==k)
                printf("%d",k);
            else
                printf("%d * ",k);
            i=i/k;
        }
        else
        {
            k++;
        }
    }
}*/

/* c.   RECURSIVE FUNCTION TO PRINT FIBONACCI SERIES *//*
void rec(int);
int main(void)
{
    clrscr();
    int num;

    printf("------------ RECURSIVE FUNCTION TO PRINT FIBONACCI SERIES ------------\n\n");

    printf("Enter length of series : ");
    scanf("%d",&num);

    printf("\nWith recursion, fibonacci series of length \"%d\" : \n",num);
    rec(num);

    printf("\n\n\n\nPress any key to exit................");
    getch();
    return 0;
}
void rec(int m)
{
    static int n1=0,n2=1,n3=0;

    if(m==1)
        return ;

    printf("\t\t\t%d\n",n1);

    n3 = n1 + n2;
    n1=n2;
    n2=n3;

    rec(m-1);
}*/

/* d.   RECURSIVE FUNCTION TO OBTAIN BINARY EQUIVALENT *//*
long int rec(int);
int main(void)
{
    clrscr();
    int num;

    printf("------------ RECURSIVE FUNCTION TO OBTAIN BINARY EQUIVALENT ------------\n\n");

    printf("Enter any number : ");
    scanf("%d",&num);

    printf("\nWith recursion, binary equivalent of \"%d\" : %ld\n",num,rec(num));

    printf("\n\n\n\nPress any key to exit................");
    getch();
    return 0;
}
long int rec(int m)
{
    static int r,bin=0,p=1;

    if(m==0)
        return 0;

      r = m % 2;
      bin = bin + r * p;
      p = p*10;
      rec(m/2);

    //bin = m%2 + 10*(rec(m/2));
    return bin;
}*/

/* e.   FUNCTION TO PRINT RUNNING SUM OF FIRST 25 NATURAL NUMBERS *//*
void rec(int);
int main()
{
    clrscr();
    int num;

    printf("------------ FUNCTION TO PRINT RUNNING SUM OF FIRST N NATURAL NUMBERS ------------\n\n");

    printf("Enter length of running sum : ");
    scanf("%d",&num);

    printf("The running sum are : \n");

    rec(num);

    printf("\n\n\n\nPress any key to exit................");
    getch();
    return 0;

}
void rec(int k)
{
    static int n=1,sum=0;
    if(k==0)
        return;
    sum=sum+n;
    printf("Sum of first %02d natural numbers = %d\n",n,sum);
    n++;
    rec(k-1);
}*/

/* f.   FUNCTION TO CALULCATE EXPANSION OF sin(x) FUNCTION *//*
float rec(float);
float fact(float);
int main(void)
{
    clrscr();
    int num;
    float s;

    printf("------------ FUNCTION TO CALULCATE EXPANSION OF sin(x) FUNCTION ------------\n\n");

    printf("Enter value of x (in degrees) : ");
    scanf("%d",&num);

    s= ( num*(22.0/7.0) ) / 180.0;

    printf("\nWith recursion, sin (%d%c) : %f\n",num,248,rec(s));

    printf("\n\n\n\nPress any key to exit................");
    getch();
    return 0;
}
float rec(float x)
{
    static int i=1,p=1,j;
    float res=0.0,tot,po=1.0;

    while(i<=10)
    {
        j=1; po=1.0;
        while(j++<=p)
            po=po*x;

        tot = po / fact(p);
        p=p+2;

        if(i%2==0)
            res=res-tot;
        else
            res=res+tot;
        i++;
    }

    return res;
}
float fact(float k)
{
    float i;
    float f=1;
    for(i=k;i>0;i=i-1.0)
        f=f*i;
    return f;
}*/

/* g.   FUNCTION TO CIRCULARLY SHIFT THE VALUES OF 3 VARIABLES *//*
void fun(int *,int *,int *);
int main(void)
{
    clrscr();
    int x,y,z;

    printf("------------ FUNCTION TO CIRCULARLY SHIFT THE VALUES OF 3 VARIABLES ------------\n\n");

    printf("Enter value of x, y and z : ");
    scanf("%d %d %d",&x,&y,&z);

    fun(&x,&y,&z);

    printf("\nAfter circular shift : x=%d , y=%d , z=%d\n",x,y,z);

    printf("\n\n\n\nPress any key to exit................");
    getch();
    return 0;
}
void fun(int *j, int *k, int *l)
{
    int t;

    t=*j;
    *j=*k;
    *k=*l;
    *l=t;
}
*/

/* h.   FUNCTION TO OBTAIN BINARY EQUIVALENT OF A NUMBER *//*
void fun(int);
int main(void)
{
    clrscr();
    int x,y,z;

    printf("------------ FUNCTION TO CIRCULARLY SHIFT THE VALUES OF 3 VARIABLES ------------\n\n");

    printf("Enter a number : ");
    scanf("%d",&x);

    fun(x);

    printf("\n\n\n\nPress any key to exit................");
    getch();
    return 0;
}
void fun(int i)
{
    long int r,bin=0,p=0,t;

    printf("\nThe binary equivalent of \"%d\" = ",i);

    while(i>0)
    {
        r=i%2;
        t=power(10,p);
        bin = bin + r * t;
        p++;
        i=i/2;
    }

    printf("%ld",bin);
}*/

/* i.   FUNCTION TO CALCULATE AREA OF TRIANGLE *//*
float area(int,int,int);
int main(void)
{
    clrscr();
    int x,y,z;
    float a;

    printf("------------ FUNCTION TO CALCULATE AREA OF TRIANGLE ------------\n\n");

    printf("Enter the length of sides (in cm) : ");
    scanf("%d %d %d",&x,&y,&z);

    a=area(x,y,z);

    printf("\nArea of given triangle = %.2f square cm",a);

    printf("\n\n\n\nPress any key to exit................");
    getch();
    return 0;
}
float area(int i, int j, int k)
{
    float s,r;

    s = (i+j+k)/2.0;
    r = sqrt( s*(s-i)*(s-j)*(s-k) );
    return r;
}*/

/* j.   FUNCTION TO CALCULATE DISTANCE BETWEEN POINTS, FIND AREA AMD CHECK POINT *//*
float area(float,float,float);
float distance(float,float,float,float);
void check();
int main(void)
{
    clrscr();
    int i,j,k,l;

    printf("------------ FUNCTION TO CALCULATE DISTANCE BETWEEN POINTS, FIND AREA AMD CHECK POINT ------------\n\n");

    printf("Enter coordinates of 1st point : ");
    scanf("%d %d",&i,&j);
    printf("Enter coordinates of 2nd point : ");
    scanf("%d %d",&k,&l);

    printf("\nDistance between 2 points = %.2f units\n",distance(i,j,k,l));

    check();

    printf("\n\n\n\nPress any key to exit................");
    getch();
    return 0;
}
float area(float i, float j, float k)
{
    float s,r;

    s = (i+j+k)/2.0;
    r = sqrt( s*(s-i)*(s-j)*(s-k) );
    return r;
}
float distance(float i, float j,float k, float l)
{
    float d;

    d = sqrt ( power(k-i,2) + power(l-j,2) );
    return d;
}
void check()
{
    int x,y,i,j,k,l,a,b,c,u,v,p1,p2,p3;
    float ar,ar1,ar2,ar3;

    printf("\n\nEnter the coordinates of vertices A : ");
    scanf("%d %d",&x,&y);
    printf("Enter the coordinates of vertices B : ");
    scanf("%d %d",&i,&j);
    printf("Enter the coordinates of vertices C : ");
    scanf("%d %d",&k,&l);

    a = distance(x,y,i,j);
    b = distance(x,y,k,l);
    c = distance(i,j,k,l);

    ar=area(a,b,c);

    printf("\nArea of given triangle = %.2f square cm\n\n",a);

    printf("Enter coordinate of point to be checked : ");
    scanf("%d %d",&u,&v);

    p1 = distance(u,v,x,y);
    p2 = distance(u,v,i,j);
    p3 = distance(u,v,k,l);

    ar1 = area (p1,p2,a);
    ar2 = area (p1,p3,b);
    ar3 = area (p2,p3,c);

    if((ar1+ar2+ar3)-ar <= 0.01)
        printf("\nThe given point lies inside triangle.\n");
    else
        printf("\nThe given point does not lie inside triangle.\n");
}*/

/* k.   FUNCTION TO IMPLEMENT EUCID'S THEROREM TO FIND GCD *//*
int fun(int,int);
int main(void)
{
    clrscr();
    int j,k;

    printf("------------ FUNCTION TO IMPLEMENT EUCID'S THEROREM FOR FINDIND GCD ------------\n\n");

    printf("Enter the value of J : ");
    scanf("%d",&j);
    printf("Enter the value of K : ");
    scanf("%d",&k);

    printf("\nGreatest Common Divisor = %d",fun(j,k));

    printf("\n\n\n\nPress any key to exit................");
    getch();
    return 0;
}
int fun(int j, int k)
{
    int r,i;

    if(j<k)
        i=j;
    else
        i=j/k;

    r = j - i * k;

    if(r==0)
        return k;

    j=k;
    k=r;
    fun(j,k);
}*/

/* ------------------ END OF CHAPTER ------------------ */
