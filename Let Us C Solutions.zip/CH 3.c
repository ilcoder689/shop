#include<stdio.h>
#include<conio.h>
#include<string.h>
#include<stdlib.h>
#include<math.h>
void clrscr(){system("cls || clear");}

/*-------------CH : THE LOOP CONTROL STRUCTURE ---------------- */

/* SOLUTION A :
                a.  Unpredictable because "j" is not initialized
                b.  Indefinite loop because of ; after while loop
                c.  Unpredictable because "j" is not initialized
                d.  0
                e.  0
                f.  Incorrect Syntax of "while" loop. Use "for" loop instead.
                g.  2   3   3
                h.  3   3   1
                i.  infinite loop : prints "malyalam is palindrome." indefinitely
                j.  infinite loop : prints "A computer buff!." indefinitely
                k.  infinite loop : prints "10" indefinitely
                l.  No output
                m.  infinite loop : prints "In while loop." indefinitely
                n.  infinite loop because "x" is of char data type and x=128 will result in x=-128
                o.  3   1
                    1   3
                    0   4
                    -1  5
                p.  4   0
                    3   1
*/

/* SOLUTION B : */
/* a.   CALCULATE OVERTIME PAY OF 10 EMPLOYEES *//*
int main(void)
{
    clrscr();
    int hour,i=1,otp;

    while(i<=10)
    {
        printf("Enter no. of hours worked for Employee #%d : ",i);
        scanf("%d",&hour);

        if(hour>40)
        {
            otp = (hour - 40)*12;
            printf("\nOvertime Paid to Employee #%d : Rs. %d",i,otp);
        }
        else if(hour<=40 && hour>=0)
        {
            printf("\nOvertime pay is not applicable for Employee #%d because hours worked <= 40.",i);
        }
        else
        {
            printf("\nInvalid Input. \nPlease enter again.");
            i--;
        }

        printf("\n\n\n");
        i++;
    }

    printf("\n\n\n\n............Press any key to exit............\n\n\n\n");
    getch();
    return 0;
}*/

/* b.   FACTORIAL OF A NUMBER *//*
int main(void)
{
    clrscr();
    int num,i;
    double fact=1;

    printf("Enter a number : ");
    scanf("%d",&num);
    i=num;

    if(num<0)
    {
        printf("\nInvalid Input.\nPlease Run Again.");
    }
    else
    {
        while(i>0)
        {
            fact=fact*i;
            i--;
        }

        printf("\n\nThe Factorial of given number : %d ! = %.0f or %e",num,fact,fact);
    }

    printf("\n\n\n\n............Press any key to exit............\n\n\n\n");
    getch();
    return 0;
}*/

/* c.   CALCULATE POWER OF A NUMBER *//*
int main(void)
{
    clrscr();
    float num,pow,pow_1;
    double sol=1;

    printf("Enter a number : ");
    scanf("%f",&num);
    printf("Enter power : ");
    scanf("%f",&pow);
    pow_1=pow;

    while(pow>0)
    {
        sol= sol * num;
        pow--;
    }

    printf("\n\nThe Answer is : %.2f ^ %.2f = %.4f or %e",num,pow_1,sol,sol);

    printf("\n\n\n\n............Press any key to exit............\n\n\n\n");
    getch();
    return 0;
}*/

/* d.   PRINT ASCII CHART USING WHILE LOOP *//*
int main(void)
{
    clrscr();
    int ascii=0;

    printf("--------- ASCII VALUES CHART ---------\n\n");

    while(ascii<=255)
    {
        printf("Character : %c \t\t\t||\t\t\t Ascii Value : %d\n",ascii,ascii);
        ascii ++;
    }

    printf("\n\n\n\n............Press any key to exit............\n\n\n\n");
    getch();
    return 0;
}*/

/* e.   PRINT ARMSTRONG NUMBER BETWEEN 1 AND 500 *//*
int main(void)
{
    clrscr();
    int i=1,sum,num,r,count=0;

    printf("--------- ARMSTRONG NUMBERS BETWEEN 1 AND 500 ---------\n\n");

    while(i<=500)
    {
        sum=0;
        num=i;
        while(num>0)
        {
            r=num%10;
            sum=sum+r*r*r;
            num=num/10;
        }
        if(sum==i)
        {
            printf("%d\n",i);
            count ++;
        }
        i++;
    }

    printf("Total count of armstrong numbers : %d\n",count);

    printf("\n\n\n\n............Press any key to exit............\n\n\n\n");
    getch();
    return 0;
}*/

/* f.   MATCHSTICK GAME *//*
int main(void)
{
    clrscr();
    int m=21,uc,cc,ch=0;

    printf("--------- MATCHSTICK GAME ---------\n\n");

    while(1)
    {
        printf("No. of Matchsticks Left : %d",m);
        while(1)
        {
            printf("\nSelect no. of matchsticks (1,2,3 or 4) : ");
            scanf("%d",&uc);
            if(uc>=1 && uc<=4)
                break;
            else
            {
                printf("Invalid Input. Re-Select .");
                continue;
            }
        }
        m=m-uc;
        printf("No. of Matchsticks Left : %d",m);
        cc=5-uc;
        printf("\nThe Computer selected : %d Matchsticks\n\n",cc);
        m=m-cc;

        if(m==1)
        {
            printf("No. of Matchsticks Left : %d",m);
            printf("\n****** GAME OVER ******\nYOU LOSE THE GAME.");
            printf("\n\nPlay Again ? ( Yes(1)/No ) : ");
            scanf("%d",&ch);

            if(ch==1)
            {
                m=21;
                continue;
            }
            else
            {
                break;
            }
        }
    }

    printf("\n\n\n\n............Press any key to exit............\n\n\n\n");
    getch();
    return 0;
}*/

/* g.   COMPUTER'S MEMORY GAME *//*
int main(void)
{
    clrscr();
    int num,nz=0,np=0,nn=0,ch=0;

    printf("--------- COMPUTER'S MEMORY GAME ---------\n\n");

    while(1)
    {
        printf("Enter the Number : ");
        scanf("%d",&num);

        if(num<0)
            nn++;
        else if (num>0)
            np++;
        else if (num==0)
            nz++;

        printf("Enter Again ? ( Yes(1)/No ) : ");
        scanf("%d",&ch);
        printf("\n\n");

        if(ch==1)
        {
            continue;
        }
        else
        {
            break;
        }

    }

    printf("\nThe No. of zeroes = %d\nThe No. of Positive Numbers = %d\nThe No. of Negative Numbers = %d\n",nz,np,nn);

    printf("\n\n\n\n............Press any key to exit............\n\n\n\n");
    getch();
    return 0;
}*/

/* h.   OCTAL EQUIVALENT OF A NUMBER *//*
int main(void)
{
    clrscr();
    int num,n,oct=0,p=0,r;

    printf("--------- OCTAL EQUIvALENT OF DECIMAL NUMBER ---------\n\n");

    printf("Enter the Number : ");
    scanf("%d",&num);
    n=num;

    while(num>0)
    {
        r=num%8;
        num=num/8;
        oct=oct+ r * pow(10,p);
        p++;
    }

    printf("\nThe Octal Equivalent of \"%d\" Number : %d",n,oct);

    printf("\n\n\n\n............Press any key to exit............\n\n\n\n");
    getch();
    return 0;
}*/

/* i.   FIND RANGE OF A SET OF NUMBERS *//*
int main(void)
{
    clrscr();
    int num,count,big,small,flag=0,i=1,range;

    printf("--------- RANGE OF A SET OF NUMBERS ---------\n\n");

    printf("Enter the total Numbers : ");
    scanf("%d",&count);

    if(count<=0)
        printf("Invalid Input.");
    else
    {
        while(count>0)
        {
        printf("Enter #%d Number : ",i++);
        scanf("%d",&num);

        if(flag==0)
        {
            big=small=num;
            flag=1;
        }
        else
        {
            if(num>big)
                big=num;
            if(num<small)
                small=num;
        }
        count--;
        }

        range=abs(big-small);

        printf("\nThe Range of given set of Numbers : %d",range);
    }
    printf("\n\n\n\n............Press any key to exit............\n\n\n\n");
    getch();
    return 0;
}*/

/* SOLUTION C :
                a.  No Output
                b.  "1" will be printed indefinitely
                c.  2   5
                d.  "A" will be printed indefinitely
*/

/* SOLUTION D :
                a.  The three parts of the loop expression in the for loop are:
                    the initialization expression
                    the testing/conditioning expression
                    the incrementation/decrement expression
                b.  arithmetic, relational, assignment is operation hierarchy in absence of parenthesis
                c.  The break statement is used to exit from a LOOP.
                d.  A do-while loop is useful when we want that the statements within the loop must be executed AT LEAST ONCE
                e.  Initialization, execution of body, testing is sequence of DO-WHILE LOOP
                f.  int True = 0, false ;
                    while ( True )
                    {
                    False = 1 ;
                    }   IS NOT AN INFINITE LOOP
                g.  "continue" keyword is used to take the control to the beginning of the loop
*/

/* SOLUTION E : */
/* a.   PRIME NUMBERS BETWEEN 1 AND 300 *//*
int main (void)
{
    clrscr();
    int i,u=2,flag=0,count=0,sum=0;

    printf("--------- LIST OF PRIME NUMBERS BETWEEN 1 AND 300 ---------\n\n");


    for(i=2;i<=300;i++)
    {
        flag=0;
        for(u=2;u<=i/2;u++)
        {
            if(i%u==0)
            {
                flag=1;
                break;
            }
        }

        if(flag==0)
        {
            count ++ ;
            sum = sum + i;
            printf("\t%d\n",i);
        }
    }

    printf("\nCount of prime numbers : %d",count);
    printf("\nSum of prime numbers   : %d",sum);

    printf("\n\n\n\n............Press any key to exit............\n\n\n\n");
    getch();
    return 0;
}*/

/* b.   FILL SCREEN WITH SMILING FACE *//*
int main (void)
{
    clrscr();
    int r=0,c=0;

    //printf("--------- FILL SCREEN WITH SMILING FACE ---------\n\n");


    for(r=1;r<=32;r++)
    {
        for(c=1;c<=200;c++)
        {
            printf("%c",1);
        }
        printf("\n");
    }

//    printf("\n\n\n\n............Press any key to exit............\n\n\n\n");
    getch();
    return 0;
}*/

/* c.   ADD TERMS OF A SERIES *//*
int main (void)
{
    clrscr();
    int i=1,num;
    float fact=1,sum=0;

    printf("--------- ADD SEVEN TERMS OF SERIES 1/1! + 2/2! + 3/3! + ...... ---------\n\n");


    for(i=1;i<=7;i++)
    {
        fact=1;
        for(num=i;num>0;num--)
        {
            fact=fact*num;
        }
        sum = sum + (i/fact);
    }

    printf("\nThe sum of first seven terms of given series = %f",sum);

    printf("\n\n\n\n............Press any key to exit............\n\n\n\n");
    getch();
    return 0;
}*/

/* d.   GENERATE COMBINATIONS *//*
int main (void)
{
    clrscr();
    int i,j,k;

    printf("--------- GENERATE COMBINATIONS OF 1 , 2 AND 3 ---------\n\n");


    for(i=1;i<=3;i++)
    {
        for(j=1;j<=3;j++)
        {
            for(k=1;k<=3;k++)
            {
                    printf("%d  %d  %d\n",i,j,k);
            }
        }
    }

    printf("\n\n\n\n............Press any key to exit............\n\n\n\n");
    getch();
    return 0;
}*/

/* e.   CALCULATE INTELLLIGENCEUSING GIVEN FORMULA *//*
int main (void)
{
    clrscr();
    float i,y,x;

    printf("--------- CALCULATE INTELLIGENCE TABLE ---------\n\n");


    printf("\n\n\tY\t\tX\t\tI\n\n");

    for(y=1;y<=6;y++)
    {
        for(x=5.5;x<=12.5;x=x+0.5)
        {
           i = 2 + (y + 0.5*x);
           printf("\t%.2f\t\t%.2f\t\t%.2f\n",y,x,i);
        }
    }

    printf("\n\n\n\n............Press any key to exit............\n\n\n\n");
    getch();
    return 0;
}*/

/* f.   PRINT PATTERN #1 *//*
int main (void)
{
    clrscr();
    int a=65,bs,i,b=71;

    printf("------------ PRINT PATTERN #1 ------------\n\n");

    for(i=0;i<7;i++)
    {
        printf("\t");
        for(a=65;a<=b;a++)
        {
           printf("%c ",a);
        }

        for(bs=0;bs<2*i-1;bs++)
            printf("  ");

        if(i==0)
            b--;

        for(a=b;a>=65;a--)
            printf("%c ",a);

        if(i>0)
            b--;

        printf("\n\n");
    }

    printf("\n\n\n\n............Press any key to exit............\n\n\n\n");
    getch();
    return 0;
}*/

/* g.   FILL ENTIRE SCREEN WITH DIAMOND AND HEART *//*
int main (void)
{
    clrscr();
    int r,c;

   //printf("------------ FILL ENTIRE SCREEN WITH DIAMOND AND HEART ------------\n\n");

    for(r=0;r<=31;r++)
    {
        for(c=0;c<=200;c++)
        {
           printf("%c%c",3,4);
        }
        printf("\n");
    }

    //printf("\n\n\n\n............Press any key to exit............\n\n\n\n");
    getch();
    return 0;
}*/

/* h.   PRINT MULTIPLICATION TABLE *//*
int main (void)
{
    clrscr();
    int num,i;

    printf("------------ PRINT MULTIPLICATION TABLE ------------\n\n");

    printf("Enter a number : ");
    scanf("%d",&num);

    for(i=1;i<=10;i++)
    {
        printf("\n%d * %d = %d",num,i,i*num);
    }

    printf("\n\n\n\n............Press any key to exit............\n\n\n\n");
    getch();
    return 0;
}*/

/* i.   PRINT PATTERN #2 *//*
int main (void)
{
    clrscr();
    int i,j,bs,num=1;

    printf("------------ PRINT PATTERN #2 ------------\n\n");

    for(i=1;i<=4;i++)
    {
        printf("\t\t");
        for(j=4;j>=i;j--)
            printf(" ");
        for(j=1;j<=i;j++)
            {
                printf("%d",num++);
                printf(" ");
            }
        printf("\n\n");
    }

    printf("\n\n\n\n............Press any key to exit............\n\n\n\n");
    getch();
    return 0;
}*/

/* j.   PRINT PATTERN #3 (PASCAL'S TRIANGLE) *//*
int main (void)
{
    clrscr();
    int i,j,val,n;

    printf("------------ PRINT PATTERN #3 (PASCAL'S TRIANGLE) ------------\n\n");

    printf("Enter no. of rows : ");
    scanf("%d",&n);

    for(i=0;i<n;i++)
    {
        printf("\t\t");
        for(j=n;j>=i;j--)
            printf("  ");
        for(j=0;j<=i;j++)
            {
                if(i==0 || j==0)
                    printf("%4d",val=1);
                else
                    printf("%4d",val=val*(i-j+1)/j);//or We can use val(i,j) = i! / ( (i-j)! * j! )
            }
        printf("\n\n");
    }

    printf("\n\n\n\n............Press any key to exit............\n\n\n\n");
    getch();
    return 0;
}*/

/* k.   MINIMUM LIFE OF MACHINE *//*
int main (void)
{
    clrscr();
    int p=6000,year=1;
    float v1,v2,interest;

    printf("------------ MINIMUM LIFE OF MACHINE ------------\n\n");

    for(year=1;;year++)
    {
        v1 = 2000 + 1000*year;
        interest = 6000 * 12 * year / 100;
        v2 = 6000 + interest ;
        if(v1>v2)
        {
            break;
        }
    }

    printf("\n\nThe minimum life of machine : %d",year);
    printf("\nProfit on Machine : %.2f",v1-6000);
    printf("\nProfit on alternate : %.2f",v2-6000);

    printf("\n\n\n\n............Press any key to exit............\n\n\n\n");
    getch();
    return 0;
}*/

/* l.   COMPOUND INTEREST CALCULATION *//*
int main (void)
{
    clrscr();
    float p,q,r,n,a;
    int i,c;

    printf("------------ COMPOUND INTEREST CALCULATION ------------\n\n");

    printf("Enter number of times to calculate : ");
    scanf("%d",&c);

    for(i=1;i<=c;i++)
    {
        printf("Enter Principal Amount : ");
        scanf("%f",&p);
        printf("Enter rate of Interest (in %% ) : ");
        scanf("%f",&r);
        printf("Enter the no. of years : ");
        scanf("%f",&n);
        printf("Enter compound  period : ");
        scanf("%f",&q);
        a = p * pow( (1 + r/(100*q)),n*q);
        printf("\nTotal Amount : Rs. %.2f",a);
        printf("\n\n");
    }

    printf("\n\n\n\n............Press any key to exit............\n\n\n\n");
    getch();
    return 0;
}*/

/* m.   FINDING LOG UPTO FIRST SEVEN TERM AS PER GIVEN SERIES *//*
int main (void)
{
    clrscr();
    int x,i;
    float sum=0;

    printf("--------- FINDING LOG(X) AS PER GIVEN SERIES ---------\n\n");

    printf("Enter value of X : ");
    scanf("%d",&x);

    for(i=1;i<=7;i++)
    {
        if(i==1)
            sum = sum + pow((x-1.0)/x,i);
        else
            sum = sum + (1.0/2) * pow( (x-1.0)/x , i );
    }

    printf("\nln(%d) = %f and %f",x,sum,log(x));

    printf("\n\n\n\n............Press any key to exit............\n\n\n\n");
    getch();
    return 0;
}*/


/* **************************** END OF CHAPTER **************************** */
