#include<stdio.h>
#include<conio.h>
#include<string.h>
#include<stdlib.h>
#include<math.h>
void clrscr(){system("cls || clear");}
long long int power(float k, long int l) {float i=l,res=1.0; while(i-->0)res=res*k; return res; }

/*-------------CH : ARRAYS ---------------- */

/* SOLUTION A :
                a.  200 100
                b.  65  A   ............    90   Z
                c.  49
*/

/* SOLUTION B :
                a.  ERROR - Array can't have two data types
                b.  ERRORS - i undeclared ; address of operator not used in scanf()
                c.  NO ERROR
*/

/* SOLUTION C :
                a.  An array is a collection of the same data type placed next to each other in memory
                b.  Ideally, all declarations are wrong
                c.  num[4] refers to 5th element in array
                d.  In int num[5], 5 is size of array or total number of elements in the array while
                    num[5]=11 refers to the 6th element of the array.
                e.  1. True
                    2. False
                    3. False
                    4. True
*/

/* SOLUTION D : */
/*  a.  SEARCH A SPECIFIC ELEMENT AND COUNT IN AN ARRAY *//*
int main()
{
    clrscr();
    int arr[25],ele,count=0,size,i;

    while(1)
    {
        printf("Enter no. of elements (<=25) : ");
        scanf("%d",&size);

        if(size>0 && size<=25)
            break;

        else
        {
            printf("\nInvalid input. Retry.");
            getch();
            clrscr();
            continue;
        }
    }

    printf("Enter elements : \n");
    for(i=0;i<size;i++)
        scanf("%d",&arr[i]);
    printf("\nEnter element to search : ");
    scanf("%d",&ele);

    for(i=0;i<size;i++)
    {
        if(ele==arr[i])
        {
            count++;
        }
    }

    if(count>0)
    {
        printf("\n%d is found in array %d times.",ele,count);
    }
    else
    {
        printf("\n%d is not found in array.",ele);
    }

    printf("\n\n\n\nPress any key to exit............");
    getch();
    return 0;
}*/

/*  b.  COUNT POSITIVE, NEGATIVE, ZERO, ODD OR EVEN *//*
int main()
{
    clrscr();
    int a[25],no=0,ne=0,np=0,nn=0,n0=0,size,i;

    while(1)
    {
        printf("Enter no. of elements (<=25) : ");
        scanf("%d",&size);

        if(size>0 && size<=25)
            break;

        else
        {
            printf("\nInvalid input. Retry.");
            getch();
            clrscr();
            continue;
        }
    }

    printf("Enter elements : \n");
    for(i=0;i<size;i++)
        scanf("%d",&a[i]);

    for(i=0;i<size;i++)
    {
        if(a[i]%2==0)
            ne++;
        else
            no++;
        if(a[i]==0)
            n0++;
        else if(a[i]>0)
            np++;
        else
            nn++;
    }

    printf("\nNo. of Odd Numbers in array = %d",no);
    printf("\nNo. of Even Numbers in array = %d",ne);
    printf("\nNo. of Zero Numbers in array = %d",n0);
    printf("\nNo. of Positive Numbers in array = %d",np);
    printf("\nNo. of Negative Numbers in array = %d",nn);

    printf("\n\n\n\nPress any key to exit............");
    getch();
    return 0;
}*/

/*  c.  IMPLEMENT BUBBLE SORT, SELECTION SORT AND INSERTION SORT    *//*
void i_sort(int *i,int j);
void s_sort(int *i,int j);
void b_sort(int *i,int j);
int main()
{
    clrscr();
    int a[25],b[25],c[25],size,i;

    while(1)
    {
        printf("Enter no. of elements (<=25) : ");
        scanf("%d",&size);

        if(size>0 && size<=25)
            break;

        else
        {
            printf("\nInvalid input. Retry.");
            getch();
            clrscr();
            continue;
        }
    }

    printf("Enter elements : \n");
    for(i=0;i<size;i++)
        {
            scanf("%d",&a[i]);
            b[i]=a[i];
            c[i]=a[i];
        }

    b_sort(a,size);
    s_sort(b,size);
    i_sort(c,size);

    printf("\n\n\n\nPress any key to exit............");
    getch();
    return 0;
}
void i_sort(int *a, int size)
{
    int i,j,t,c=1,l=1;

    printf("\n\n--------- INNSERTION SORT ---------\n");
    for(i=1;i<size;i++)
    {
        t=a[i];
        printf("\nIteration : %d\t",c++);

        for(j=0;j<i;j++)
        {
            if(a[j]>t)
            {
                for(l=i;l>=j;l--)
                    a[l]=a[l-1];
                a[j]=t;
                break;
            }
        }
    }

    printf("Sorted Array : ");
    for(i=0;i<size;i++)
        printf("%d ",a[i]);

    getch();
}

void b_sort(int *a, int size)
{
    int i,j,t,c=1,l=1;

    printf("\n\n--------- BUBBLE SORT ---------\n");
    for(i=0;i<size-1;i++)
    {
        printf("\nIteration : %d\t",c++);
        for(j=0;j<size-i-1;j++)
        {
            if(a[j]>a[j+1])
            {
                t=a[j];
                a[j]=a[j+1];
                a[j+1]=t;
            }
            printf("%d ",l++);
        }
    }

    printf("Sorted Array : ");
    for(i=0;i<size;i++)
        printf("%d ",a[i]);

    getch();
}
void s_sort(int *a, int size)
{
    int i,j,t,c=1,l=1;

    printf("\n\n--------- SELECTION SORT ---------\n");
    for(i=0;i<size-1;i++)
    {
        printf("\nIteration : %d\t",c++);
        for(j=0;j<size-i-1;j++)
        {
            if(a[j]>a[j+1])
            {
                t=a[j];
                a[j]=a[j+1];
                a[j+1]=t;
            }
            printf("%d ",l++);
        }
    }

    printf("Sorted Array : ");
    for(i=0;i<size;i++)
        printf("%d ",a[i]);

    getch();
}*/

/*  d.  SIEVE OF ERATOSTHENES   *//*
int main()
{
    clrscr();
    int a[100],size,i,j;

    for(i=0;i<100;i++)
        a[i]=i+1;

    for(i=1;i<100;i++)
    {
        if(a[i]!=0)
        {
            for(j=a[i]*2;j<=100;j=j+a[i])
                a[j-1]=0;
        }
    }

    printf("\nPrime numbers between 1 and 100 : ");
    for(i=0;i<100;i++)
    {
        if(a[i]!=0)
            printf("%d ",a[i]);
    }

    printf("\n\n\n\nPress any key to exit............");
    getch();
    return 0;
}*/

/* SOLUTION E :
                a.  10  20  30  40  50
                b.  0   20  0   40  5
                c.  7   9   11  13  15
                d.  2   4   6   8   10  16
                e.  0   0   0   0   0
                f.  3   2   15
*/

/* SOLUTION F :
                a.  NO ERROR : BUT ARRAY BOUNDS ARE BEING EXCEEDED
                b.  NO ERROR : BUT ARRAY BOUNDS ARE BEING EXCEEDED
                c.  ERROR : j is not a pointer variable
                d.  NO ERROR
                e.  ERROR : POINTER CAN'T HAVE MULTIPLY AND DIVISION OPERATIONS
                f.  ERROR : i undeclared and ideally array size should not be variable
*/

/* SOLUTION G :
                a.  if you try to put so many values into an array when you initialize it that the size of the array is exceeded, possible system malfunction
                b.  In an array int arr[12] the word arr represents the "address" of the array
                c.  if you put too few elements in an array when you initialize it
                    unused elements will be filled with 0�s or garbage
                d.  if you assign a value to an element of an array whose subscript exceeds the size of the array
                    other data may be overwritten
                e.  When you pass an array as an argument to a function, address of the array gets passed
                f.  Pointers are used to manipulate the parts of an array
                g.  If you don't initialize a static array , its all elements are set to zero(0)
*/

/* SOLUTION H :
                a.  True
                b.  Correct way of float pointer : float * ptr;
                c.  ptr = &j;
                d.  *(s+2)
*/

/* SOLUTION I : */
/*  a.  COPY ONE ARRAY INTO ANOTHER IN REVERSE ORDER    *//*
int main()
{
    clrscr();
    int arr[25],n[25],size,i;

    while(1)
    {
        printf("Enter no. of elements (<=25) : ");
        scanf("%d",&size);

        if(size>0 && size<=25)
            break;

        else
        {
            printf("\nInvalid input. Retry.");
            getch();
            clrscr();
            continue;
        }
    }

    printf("Enter elements : \n");
    for(i=0;i<size;i++)
        {
            scanf("%d",&arr[i]);
            n[size-i-1]=arr[i];
        }


    printf("\nCopied Array : ");
    for(i=0;i<size;i++)
        printf("%d ",n[i]);

    printf("\n\n\n\nPress any key to exit............");
    getch();
    return 0;
}*/

/*  b.  TO CHECK arr[0] = arr[n-1] and so on    *//*
int main()
{
    clrscr();
    int arr[25],size,i;

    while(1)
    {
        printf("Enter no. of elements (<=25) : ");
        scanf("%d",&size);

        if(size>0 && size<=25)
            break;

        else
        {
            printf("\nInvalid input. Retry.");
            getch();
            clrscr();
            continue;
        }
    }

    printf("Enter elements : \n");
    for(i=0;i<size;i++)
        {
            scanf("%d",&arr[i]);
        }

    printf("\nElements following conditions : ");
    for(i=0;i<size;i++)
        if(arr[i]==arr[size-1-i])
            printf("%d ",i+1);

    printf("\n\n\n\nPress any key to exit............");
    getch();
    return 0;
}*/

/*  c.  TO FIND SMALLEST NUMBER IN ARRAY USING POINTER  *//*
int main()
{
    clrscr();
    int arr[25],size,i,s;

    while(1)
    {
        printf("Enter no. of elements (<=25) : ");
        scanf("%d",&size);

        if(size>0 && size<=25)
            break;

        else
        {
            printf("\nInvalid input. Retry.");
            getch();
            clrscr();
            continue;
        }
    }

    printf("Enter elements : \n");
    for(i=0;i<size;i++)
        {
            scanf("%d",&arr[i]);
        }

    s = (*arr);
    for(i=0;i<size;i++)
        if(*(arr+i)<s)
            s= *(arr+i);
    printf("\nSmallest number in array = %d",s);

    printf("\n\n\n\nPress any key to exit............");
    getch();
    return 0;
}*/

/*  d.  TO PERFORM MODIFICATION OF ARRAY    *//*
void modify(int *,int);
int main()
{
    clrscr();
    int i;
    int arr[10] = {1,2,3,4,5,6,7,8,9,10};

    printf("\nInitially Array : ");
    for(i=0;i<10;i++)
        printf("%d ",arr[i]);

    modify(arr,10);

    printf("\nAfter Modification Array : ");
    for(i=0;i<10;i++)
        printf("%d ",arr[i]);

    printf("\n\n\n\nPress any key to exit............");
    getch();
    return 0;
}
void modify(int *a,int size)
{
    int i;
    for(i=0;i<size;i++)
        *(a+i)*=3;
}*/

/*  e.  DANCING DOLL VIRUS  *//*
NOT APPLICABLE NOW*/
