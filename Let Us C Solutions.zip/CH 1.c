#include<stdio.h>
#include<conio.h>
#include<string.h>
#include<stdlib.h>
void clrscr(){system("cls || clear");}

/*-------------CH : GETTING STARTED ---------------- */

/* SOLUTION A : basic-hra, #mean, group. , 422, population in 2006, overtime, queue. , team'svictory, PLOT#3, 2015_DDAY */

/* SOLUTION B : AS PER SOLUTION BOOK */

/* SOLUTION C : AS PER SOLUTION BOOK */

/* SOLUTION D : AS PER SOLUTION BOOK */

/* SOLUTION E : AS PER SOLUTION BOOK */

/* SOLUTION F :
                a.  0   2   0.000000    2.000000
                b.  a=0     b=-6
                c.  ERROR ( CAN'T USE '%' OPERATOR TO FLOAT TYPE VALUES
                d.  nn

                     nn
                    nn /n/n nn/n
                e.  USER INPUT BASED
                f.  USER INPUT BASED
*/

/* SOLUTION G :
                a. Dennis Ritchie developed C language
                b. C Can be used on MS-DOS, WINDOWS AND LINUX
                c. Compiler converts program into machine language
                d. Real values in C can be expressed in Fractional or exponential foem
                e. at most 1 character in char variable
                f. The statement char ch = �Z� would store in ch the character Z and its ASCII Value
                g. all of the above
                h. An integer can have max value 32767
                i. C variable can't start with number or any special symbol other than _
                j. 3+a=b is wrong
                k. / or *, - or + is correct hierarchy
                l. 6.6/a
                m. only () is allowed in arithmetic expression
                n. Each new C instruction does not need to be written on a separate line
                o. For int , a=5/2 returns 2
                p. 0 (zero)
                q. short int a= 30*1000 + 2767; returns -32768
                r. a= 4 + 2%-8; returns 6
                s. Hierarchy decides which operator is used first
                t. An integer constant in C must have atleast 1 digit
                u. A character variable can never store more than 1 variable.
                v. In C a variable cannot contain a space or hyphen or a decimal point
                w. Keywords can not be used as variable names
                x. In C, Arithmetic instruction cannot contain constants on LHS of =
                y. * / + -
                z. d = 2 / 7.0 returns 0.2857
*/

/* SOLUTION H : */
/* a.  Calculation of GROSS SALARY *//*
int main()
{
    clrscr();
    int basic, gross;
    float da, hra;

    printf("Enter Basic Salary of Ramesh : ");
    scanf("%d",&basic);

    hra=basic*20/100;
    da=basic*40/100;


    gross= basic + hra + da;
    printf("\nThe D.A. is %.2f\nThe HRA is %.2f\nThe gross salary is %d\n\nPress any key to exit.........",da,hra,gross);
    getch();
    return 0;
}*/

/* b. CONVERSION OF DISTANCE *//*
int main()
{
    clrscr();
    float km, mt, feet, inch, cm;

    printf("Enter distance between two cities in KM : ");
    scanf("%f",&km);

    mt=km*1000;
    cm=mt*100;
    inch = cm/2.54;
    feet= inch/12;

    printf("\nThe Distance is \n%.2f KM \n%.2f Meters\n%.2f Centimeters\n%.2f Inches\n%.2f Feet\n\n\nPress any key to exit.........",km,mt,cm,inch,feet);
    getch();
    return 0;
}*/

/* c. PERCENTAGE OF 5 MARKS *//*
int main()
{
    clrscr();
    float _1,_2,_3,_4,_5,_t,_p;

    printf("Enter Marks of the student : (Out of 100) \n");
    printf("First Subject : ");
    scanf("%f",&_1);
    printf("Second Subject : ");
    scanf("%f",&_2);
    printf("Third Subject : ");
    scanf("%f",&_3);
    printf("Fourth Subject : ");
    scanf("%f",&_4);
    printf("Fifth Subject : ");
    scanf("%f",&_5);

    _t = _1+_2+_3+_4+_5; // aggregate marks
    _p = _t/5;

    printf("\nThe Aggregate Marks = %.2f \nThe percentage = %.2f %% \n\n\n\nPress any key to exit.........",_t,_p);
    getch();
    return 0;
}*/

/* d. TEMPERATURE CONVERSION *//*
int main()
{
    clrscr();
    float c,f;

    printf("Enter Temperature in Fahrenheit : ");
    scanf("%f",&f);

    c = 5.0/9.0*(f-32);

    printf("\nThe Temperature in \nFahrenhiet : %.2f\nCelsius : %.2f \n\n\n\nPress any key to exit.........",f,c);
    getch();
    return 0;
}*/

/* e. AREA OF RECTANGLE AND CIRCLE*//*
int main()
{
    clrscr();
    float l,b,ar,ac,pr,cc,r;

    printf("Enter Radius of Circle (in cm) : ");
    scanf("%f",&r);
    ac = 3.14 * r * r;
    cc = 2 * 3.14 * r;
    printf("\nArea of circle : %.2f cm^2 \n",ac);
    printf("Circumference of circle : %.2f cm \n",cc);

    printf("\nEnter length of rectangle (in cm) : ");
    scanf("%f",&l);
    printf("Enter breadth of rectangle (in cm) : ");
    scanf("%f",&b);
    ar = l * b;
    pr = 2 * (l + b);
    printf("\nArea of Rectangle : %.2f cm^2 ",ar);
    printf("\nPerimeter of Rectangle : %.2f cm ",pr);

    printf("\n\n\n\nPress any key to exit.........");
    getch();
    return 0;
}*/

/* f. SWAP TWO NUMBERS *//*
int main()
{
    clrscr();
    int c,d,t;

    printf("Enter number at location C : ");
    scanf("%d",&c);
    printf("Enter number at location D : ");
    scanf("%d",&d);

    t=c;
    c=d;
    d=t;

    printf("\nAfter interchanging : \n");
    printf("Number at location C : %d and Number at location D : %d ",c,d);

    printf("\n\n\n\nPress any key to exit.........");
    getch();
    return 0;
}*/

/* g. SUM OF DIGITS OF FIVE DIGIT NUMBER *//*
int main()
{
    clrscr();
    int n,r,sum=0,t;

    printf("Enter a five digit number : ");
    scanf("%5d",&n);
    t=n;

    for(int i=0;i<5;i++)
    {
        r = n % 10;
        sum = sum + r;
        n = n / 10;
    }

    printf("Sum of digits of number \"%05d\" = %d ",t,sum);

    printf("\n\n\n\nPress any key to exit.........");
    getch();
    return 0;
}*/

/* h. REVERSE OF 5 DIGIT NUMBER *//*
int main()
{
    clrscr();
    int n,r,sum=0,t;

    printf("Enter a five digit number : ");
    scanf("%5d",&n);
    t=n;

    for(int i=0;i<5;i++)
    {
        r = n % 10;
        if(r)
            sum = sum * 10 + r;
        n = n / 10;
    }

    printf("Reverse of number \"%05d\" = %05d ",t,sum);

    printf("\n\n\n\nPress any key to exit.........");
    getch();
    return 0;
}*/

/* i. SUM OF 1ST AND 4TH DIGIT OF 4 DIGIT NUMBER *//*
int main()
{
    clrscr();
    int n,r,sum=0,t;

    printf("Enter a four digit number : ");
    scanf("%4d",&n);
    t=n;

    for(int i=0;i<4;i++)
    {
        r = n % 10;
        if(i == 0 || i == 3)
            sum = sum + r;
        n = n / 10;
    }

    printf("Sum of 1st and 4th digit of number \"%04d\" = %d ",t,sum);

    printf("\n\n\n\nPress any key to exit.........");
    getch();
    return 0;
}*/

/* j. TOWN STATS CALCULATION *//*
int main()
{
    clrscr();
    int const pop = 80000;
    int mp = 52, lp = 48, lmp = 35;

    int nm = pop*mp/100;
    int nw = pop - nm;
    int nlm = pop * lmp / 100;
    int nilm = nm - nlm;
    int nlp = pop * lp / 100;
    int nilp = pop - nlp;
    int nlw = nlp - nlm;
    int nilw = nw - nlw;

    printf("Total number of Person : %d\n",pop);
    printf("Total number of Men : %d\n",nm);
    printf("Total number of Women : %d\n",nw);
    printf("Total number of Literate Person : %d\n",nlp);
    printf("Total number of Illiterate Person : %d\n",nilp);
    printf("Total number of Literate Men : %d\n",nlm);
    printf("Total number of illiterate Men : %d\n",nilm);
    printf("Total number of Literate Women : %d\n",nlw);
    printf("Total number of illiterate Women : %d\n",nilw);

    printf("\n\n\n\nPress any key to exit.........");
    getch();
    return 0;
}*/

/* k. CASHIER PROBLEM *//*
int main()
{
    clrscr();
    int amount, _100, _50, _10;

    printf("Enter amount : ");
    scanf("%d",&amount);

    _100 = amount / 100;
    amount %= 100;

    _50 = amount / 50;
    amount %= 50;

    _10 = amount / 10;
    amount %= 10;


    printf("Total number of Rs. 100 Notes : %d\n",_100);
    printf("Total number of Rs. 050 Notes : %d\n",_50);
    printf("Total number of Rs. 010 Notes : %d\n",_10);
    printf("Total Amount remaining : %d\n",amount);

    printf("\n\n\n\nPress any key to exit.........");
    getch();
    return 0;
}*/

/* l. COST PROFIT PROBLEM*//*
int main()
{
    clrscr();
    float cost, profit, sell_p;

    printf("Enter selling amount of 15 items : ");
    scanf("%f",&sell_p);
    printf("Enter profit amount of 15 items : ");
    scanf("%f",&profit);

    cost = sell_p - profit;

    printf("Total cost of 15 items : %.2f\n",cost);
    printf("Cost of one Item : %.2f\n",cost/15);

    printf("\n\n\n\nPress any key to exit.........");
    getch();
    return 0;
}*/

/* m. PRINT NEW NUMBER BY MODIFYING DIGIT *//*
int main()
{
    clrscr();
    int n,r,sum=0,t,a=0;

    printf("Enter a five digit number : ");
    scanf("%5d",&n);
    t=n;

    for(int i=0;i<5;i++)
    {
        r = ((n % 10) + 1)%10;
        sum = sum * 10 + r;
        n = n / 10;
    }

    n=sum;
    sum=0;
    for(int i=0;i<5;i++)
    {
        r = n % 10;
        sum = sum * 10 + r;
        n = n / 10;
    }

    printf("New Number  = %d",sum);

    printf("\n\n\n\nPress any key to exit.........");
    getch();
    return 0;
}*/

/* ---------------------------------------- END -------------------------------------- */
